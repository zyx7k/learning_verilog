function output = multiplier_modulator(sig1, sig2)
    output = sig1.*sig2;
end